import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  compress: true,

  // ── Proper HTTP cache headers for static assets ──────────────────────────
  // This tells the browser that CSS/JS files are immutable (they have unique
  // hashed filenames from Next.js), so they are never served stale.
  // The HTML pages themselves use no-cache so fresh CSS is always linked.
  async headers() {
    return [
      {
        // Next.js static assets (CSS, JS, fonts, images) have content-hash names
        // so they can be cached forever — the filename changes on every rebuild.
        source: '/_next/static/(.*)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
      {
        // HTML pages: always revalidate so users get fresh CSS references
        source: '/(.*)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=0, must-revalidate',
          },
        ],
      },
    ];
  },

  images: {
    dangerouslyAllowLocalIP: true,
    remotePatterns: [
      // Allow images from the live Hostinger backend
      { protocol: 'https', hostname: 'api.haraceylon.com', pathname: '/**' },
      // Allow images from local dev backend
      { protocol: 'http', hostname: 'localhost', port: '8001', pathname: '/**' },
    ],
    // Serve WebP format automatically for 20-30% smaller files
    formats: ['image/webp', 'image/avif'],
  },
};

export default nextConfig;
